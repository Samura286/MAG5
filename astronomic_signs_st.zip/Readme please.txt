This font is free for all use. 

All the vectors were drawn by me and I release the font for free for any use.

Help my work, all donations are greatly appreciated.

Even with a like on my facebook page can help me.

https://www.facebook.com/southype <- follow me ;)

Paypal: Southype@gmail.com

A Moon
B Sun
C Venus
D Mercury
E Mars
F Jupiter
G Saturn
H Uranus
I Uranus
J Neptune
K Ceres
L Earth
M Earth
N Palas
O Juno
P 5 Astrea
Q Vesta
R Palas
T Pluto
U Sedna
V Eris
W Makemake
X Orcus
Y Ixion
Z Moon
